if __name__ == '__main__':
    from .remoterun import main
    main()